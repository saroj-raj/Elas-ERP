export default function DashboardWidget() {
  return <div>DashboardWidget</div>;
}
