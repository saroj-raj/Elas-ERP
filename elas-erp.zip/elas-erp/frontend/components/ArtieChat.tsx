export default function ElasChat() {
  return <div>ElasChat</div>;
}
