export default function Home() {
  return <main style={{ padding: 20 }}>Elas ERP Frontend up.</main>;
}
