export default function BusinessPage() {
  return <div>Onboarding - Business</div>;
}
