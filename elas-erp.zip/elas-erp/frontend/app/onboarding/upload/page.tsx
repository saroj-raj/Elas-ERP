export default function UploadPage() {
  return <div>Onboarding - Upload</div>;
}
