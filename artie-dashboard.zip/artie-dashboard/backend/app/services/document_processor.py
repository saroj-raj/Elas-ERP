"""Document processing placeholder"""

def process_document(content: str) -> dict:
    return {"text_length": len(content)}
