"""RAG pipeline placeholder"""

def rag_query(query: str) -> dict:
    return {"query": query, "answers": []}
