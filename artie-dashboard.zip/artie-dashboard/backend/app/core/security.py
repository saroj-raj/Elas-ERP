"""Security helpers placeholder"""

def verify_token(token: str) -> bool:
    return token == "dev-token"
