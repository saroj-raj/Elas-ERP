"""Database placeholder (in-memory)"""

DB: dict = {"users": [], "teams": []}
