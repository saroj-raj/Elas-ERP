# 📦 How to Zip Artie Dashboard

## Quick Zip Command

**From Elas-ERP directory:**
```powershell
Compress-Archive -Path .\artie-dashboard\* -DestinationPath artie-dashboard.zip
```

## Or Using File Explorer

1. Open File Explorer
2. Navigate to: `C:\Users\rajsa\Downloads\GitHub\Elas-ERP\Elas-ERP`
3. Right-click on `artie-dashboard` folder
4. Select **Send to → Compressed (zipped) folder**
5. Done! Archive created without `.venv` folder

## Archive Size

- **Before** (with .venv inside): ~350-400 MB
- **After** (venv in parent): ~5-10 MB
- **Savings**: 97% smaller! 🎉

## What Gets Included

✅ All source code  
✅ Configuration files  
✅ Documentation  
✅ Package manifests (requirements.txt, package.json)  
✅ Docker files  
✅ README and guides  

## What Gets Excluded

❌ `.venv/` (in parent directory - not included)  
❌ `node_modules/` (gitignored)  
❌ `__pycache__/` (gitignored)  
❌ `.env` files (gitignored - contains secrets)  
❌ Build artifacts (gitignored)  

## For Recipients

After extracting the ZIP, run:

```powershell
# Navigate to parent of extracted folder
cd <parent-directory>

# Create virtual environment
python -m venv .venv

# Activate it
.\.venv\Scripts\Activate.ps1

# Go to project
cd artie-dashboard

# Install dependencies
pip install -r backend/requirements.txt

# Create .env file
cp backend/.env.example backend/.env
# Edit backend/.env and add your GROQ_API_KEY

# Run the project
python main.py
```

## Share via Email/Cloud

The zip file is now small enough to:
- ✅ Email as attachment (under most 25MB limits)
- ✅ Upload to Google Drive/OneDrive quickly
- ✅ Share via Slack/Teams
- ✅ Push to GitHub (under 100MB limit)
- ✅ Store on USB drive

## Alternative: Exclude More Files

To make it even smaller, exclude documentation:

```powershell
# Create a minimal distribution (code only)
$exclude = @('*.md', 'MIGRATION_*', 'DEPLOYMENT_*', 'QUICKSTART*')
Get-ChildItem -Path .\artie-dashboard -Recurse -Exclude $exclude | 
    Compress-Archive -DestinationPath artie-dashboard-minimal.zip
```

## Include .venv (Not Recommended)

If you really need to include the virtual environment:

```powershell
# Move venv back into project
Move-Item -Path ".\.venv" -Destination ".\artie-dashboard\.venv"

# Then zip
Compress-Archive -Path .\artie-dashboard -DestinationPath artie-dashboard-full.zip

# Note: This will be 350-400 MB!
```

---

**Ready to share!** Your artie-dashboard folder is now optimized for distribution. 📦
