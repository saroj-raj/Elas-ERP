export default function RoleDashboard() {
  return <div>Dashboard - Role</div>;
}
