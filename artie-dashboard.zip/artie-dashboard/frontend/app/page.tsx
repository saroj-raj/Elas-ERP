export default function Home() {
  return <main style={{ padding: 20 }}>Artie Frontend up.</main>;
}
