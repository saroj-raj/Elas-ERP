export default function TeamPage() {
  return <div>Onboarding - Team</div>;
}
