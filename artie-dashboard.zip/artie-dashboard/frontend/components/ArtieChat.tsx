export default function ArtieChat() {
  return <div>ArtieChat</div>;
}
