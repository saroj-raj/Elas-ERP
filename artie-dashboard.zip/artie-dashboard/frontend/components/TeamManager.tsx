export default function TeamManager() {
  return <div>TeamManager</div>;
}
