export default function FileUpload() {
  return <div>FileUpload</div>;
}
